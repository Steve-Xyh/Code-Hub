public class Sort	{
	public static void main (String args[]) {
		 double d1=23.4;
		 double d2=35.1;
		 if (d2>=d1)
		 	System.out.println(d2+">="+d1);
		 else
		  	System.out.println(d1+">="+d2);
	}
}
