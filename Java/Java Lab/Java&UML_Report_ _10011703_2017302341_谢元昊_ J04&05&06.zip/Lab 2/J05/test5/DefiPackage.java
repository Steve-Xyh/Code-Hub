package p1;

public class DefiPackage {
  public void display(){
    System.out.println("in method display()");
  }
}
