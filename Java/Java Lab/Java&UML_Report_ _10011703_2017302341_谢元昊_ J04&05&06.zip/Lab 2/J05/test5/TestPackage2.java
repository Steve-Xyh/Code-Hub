import p2.TestPackage;

public class TestPackage2 {
	public static void main(String[] args) {
		TestPackage t=new TestPackage();
		t.display();
	}
}
