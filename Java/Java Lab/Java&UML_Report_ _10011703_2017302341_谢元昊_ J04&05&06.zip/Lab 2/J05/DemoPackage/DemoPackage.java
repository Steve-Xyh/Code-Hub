import MainPackage.SubClass;

public class DemoPackage{
	public static void main(String args[]){
		SubClass a=new SubClass(1,2);
	}
}